# Importar bibliotecas necessárias
from sklearn.datasets import load_iris, fetch_20newsgroups
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, accuracy_score

# Carregar a base de dados Iris
iris = load_iris()
X_iris, y_iris = iris.data, iris.target

# Divisão em treino e teste
X_train_iris, X_test_iris, y_train_iris, y_test_iris = train_test_split(X_iris, y_iris, test_size=0.3, random_state=42)

# Carregar a base de dados Newsgroup
newsgroups_train = fetch_20newsgroups(subset='train', categories=['rec.sport.hockey', 'sci.space'])
newsgroups_test = fetch_20newsgroups(subset='test', categories=['rec.sport.hockey', 'sci.space'])

# Transformar o texto em TF-IDF
vectorizer = TfidfVectorizer()
X_train_newsgroup = vectorizer.fit_transform(newsgroups_train.data)
X_test_newsgroup = vectorizer.transform(newsgroups_test.data)
y_train_newsgroup = newsgroups_train.target
y_test_newsgroup = newsgroups_test.target

# Criar o modelo KNN
knn_iris = KNeighborsClassifier(n_neighbors=3)
knn_newsgroup = KNeighborsClassifier(n_neighbors=3)

# Treinar o modelo para a base Iris
knn_iris.fit(X_train_iris, y_train_iris)
y_pred_iris = knn_iris.predict(X_test_iris)

# Treinar o modelo para a base Newsgroup
knn_newsgroup.fit(X_train_newsgroup, y_train_newsgroup)
y_pred_newsgroup = knn_newsgroup.predict(X_test_newsgroup)

# Avaliação
print("Resultados para a base Iris:")
print(classification_report(y_test_iris, y_pred_iris))
print(f"Acurácia: {accuracy_score(y_test_iris, y_pred_iris):.2f}")

print("\nResultados para a base Newsgroup (com TF-IDF):")
print(classification_report(y_test_newsgroup, y_pred_newsgroup))
print(f"Acurácia: {accuracy_score(y_test_newsgroup, y_pred_newsgroup):.2f}")
