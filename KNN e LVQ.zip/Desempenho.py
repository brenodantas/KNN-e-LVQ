import numpy as np
from sklearn.datasets import load_iris, fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from minisom import MiniSom

# ---------- Base Iris (Numérica) ----------
iris = load_iris()
X_iris, y_iris = iris.data, iris.target

# Dividir a base em treino e teste
X_train_iris, X_test_iris, y_train_iris, y_test_iris = train_test_split(X_iris, y_iris, test_size=0.3, random_state=42)

# Normalizar os dados
scaler = MinMaxScaler()
X_train_iris_scaled = scaler.fit_transform(X_train_iris)
X_test_iris_scaled = scaler.transform(X_test_iris)

# KNN para base Iris
knn_iris = KNeighborsClassifier(n_neighbors=3)
knn_iris.fit(X_train_iris_scaled, y_train_iris)
y_pred_knn_iris = knn_iris.predict(X_test_iris_scaled)

# LVQ para base Iris
som_iris = MiniSom(7, 7, X_train_iris_scaled.shape[1], learning_rate=0.5, sigma=1.0, random_seed=42)
som_iris.train_random(X_train_iris_scaled, 1000)

def som_predict(som, data, X_train_scaled, y_train):
    winners = np.array([som.winner(x) for x in data])
    labels_map = {}
    for i, (x, label) in enumerate(zip(X_train_scaled, y_train)):
        winner = tuple(som.winner(x))
        if winner not in labels_map:
            labels_map[winner] = []
        labels_map[winner].append(label)
    for winner in labels_map:
        labels_map[winner] = np.bincount(labels_map[winner]).argmax()
    return np.array([labels_map.get(tuple(winner), -1) for winner in winners])

y_pred_lvq_iris = som_predict(som_iris, X_test_iris_scaled, X_train_iris_scaled, y_train_iris)

# Avaliar acurácia para KNN e LVQ na base Iris
acc_knn_iris = accuracy_score(y_test_iris, y_pred_knn_iris)
acc_lvq_iris = accuracy_score(y_test_iris, y_pred_lvq_iris)

# ---------- Base Newsgroup (Textual com TF-IDF) ----------
categories = ['rec.sport.hockey', 'rec.sport.baseball']
newsgroups_train_reviews = fetch_20newsgroups(subset='train', categories=categories)
newsgroups_test_reviews = fetch_20newsgroups(subset='test', categories=categories)

# TF-IDF para dados textuais
vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
X_train_reviews = vectorizer.fit_transform(newsgroups_train_reviews.data).toarray()
X_test_reviews = vectorizer.transform(newsgroups_test_reviews.data).toarray()
y_train_reviews = newsgroups_train_reviews.target
y_test_reviews = newsgroups_test_reviews.target

# KNN para base Newsgroup
knn_reviews = KNeighborsClassifier(n_neighbors=3)
knn_reviews.fit(X_train_reviews, y_train_reviews)
y_pred_knn_reviews = knn_reviews.predict(X_test_reviews)

# LVQ para base Newsgroup
som_reviews = MiniSom(10, 10, X_train_reviews.shape[1], learning_rate=0.5, sigma=1.0, random_seed=42)
som_reviews.train_random(X_train_reviews, 1000)
y_pred_lvq_reviews = som_predict(som_reviews, X_test_reviews, X_train_reviews, y_train_reviews)

# Avaliar acurácia para KNN e LVQ na base Newsgroup
acc_knn_reviews = accuracy_score(y_test_reviews, y_pred_knn_reviews)
acc_lvq_reviews = accuracy_score(y_test_reviews, y_pred_lvq_reviews)

# Resultados
print(f"Acurácia KNN - Iris: {acc_knn_iris:.2f}")
print(f"Acurácia LVQ - Iris: {acc_lvq_iris:.2f}")
print(f"Acurácia KNN - Newsgroup: {acc_knn_reviews:.2f}")
print(f"Acurácia LVQ - Newsgroup: {acc_lvq_reviews:.2f}")
