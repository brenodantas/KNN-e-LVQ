from minisom import MiniSom
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris, fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer

# ---------- Base Iris ----------
# Carregar a base de dados Iris
iris = load_iris()
X_iris = iris.data
y_iris = iris.target

# Dividir a base Iris em treino e teste
X_train_iris, X_test_iris, y_train_iris, y_test_iris = train_test_split(X_iris, y_iris, test_size=0.3, random_state=42)

# Pré-processamento dos dados da base Iris (normalização)
scaler = MinMaxScaler()
X_train_iris_scaled = scaler.fit_transform(X_train_iris)
X_test_iris_scaled = scaler.transform(X_test_iris)

# Configurar o MiniSom para emular LVQ
som_iris = MiniSom(7, 7, X_train_iris_scaled.shape[1], learning_rate=0.5, sigma=1.0, random_seed=42)
som_iris.train_random(X_train_iris_scaled, 1000)  # Treinar o SOM

# Mapear os protótipos aprendidos e fazer predições
def som_predict(som, data, X_train_scaled, y_train):
    winners = np.array([som.winner(x) for x in data])
    labels_map = {}

    for i, (x, label) in enumerate(zip(X_train_scaled, y_train)):
        winner = tuple(som.winner(x))  # Converte o resultado em uma tupla para usar como chave
        if winner not in labels_map:
            labels_map[winner] = []
        labels_map[winner].append(label)

    # Para cada posição vencedora, atribuir o rótulo mais comum (moda)
    for winner in labels_map:
        labels_map[winner] = np.bincount(labels_map[winner]).argmax()

    return np.array([labels_map.get(tuple(winner), -1) for winner in winners])  # Retornar -1 para casos onde o vencedor não foi mapeado

# Fazer predições com o LVQ emulado
y_pred_lvq_iris = som_predict(som_iris, X_test_iris_scaled, X_train_iris_scaled, y_train_iris)

# Avaliar o LVQ
print("Resultados do LVQ para a base Iris:")
print(f"Acurácia: {accuracy_score(y_test_iris, y_pred_lvq_iris):.2f}")

# ---------- Base Newsgroup (TF-IDF) ----------
# Carregar a base de dados Newsgroup
newsgroups_train = fetch_20newsgroups(subset='train', categories=['rec.sport.hockey', 'sci.space'])
newsgroups_test = fetch_20newsgroups(subset='test', categories=['rec.sport.hockey', 'sci.space'])

# Aplicar o TF-IDF para transformar os textos
vectorizer = TfidfVectorizer()
X_train_newsgroup = vectorizer.fit_transform(newsgroups_train.data).toarray()
X_test_newsgroup = vectorizer.transform(newsgroups_test.data).toarray()
y_train_newsgroup = newsgroups_train.target
y_test_newsgroup = newsgroups_test.target

# Configurar o MiniSom para a base Newsgroup
som_newsgroup = MiniSom(10, 10, X_train_newsgroup.shape[1], learning_rate=0.5, sigma=1.0, random_seed=42)
som_newsgroup.train_random(X_train_newsgroup, 1000)  # Treinar o SOM

# Fazer predições para a base Newsgroup
y_pred_lvq_newsgroup = som_predict(som_newsgroup, X_test_newsgroup, X_train_newsgroup, y_train_newsgroup)

# Avaliar o LVQ
print("\nResultados do LVQ para a base Newsgroup (com TF-IDF):")
print(f"Acurácia: {accuracy_score(y_test_newsgroup, y_pred_lvq_newsgroup):.2f}")
