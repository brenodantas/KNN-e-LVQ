from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.datasets import fetch_20newsgroups

# ---------- Reconhecimento de Dígitos Manuscritos (Base Numérica) ----------
# Carregar a base de dados de dígitos manuscritos
digits = load_digits()
X_digits, y_digits = digits.data, digits.target

# Dividir a base em treino e teste
X_train_digits, X_test_digits, y_train_digits, y_test_digits = train_test_split(X_digits, y_digits, test_size=0.3, random_state=42)

# Criar e treinar o modelo KNN
knn_digits = KNeighborsClassifier(n_neighbors=5)
knn_digits.fit(X_train_digits, y_train_digits)

# Fazer predições e avaliar o modelo
y_pred_digits = knn_digits.predict(X_test_digits)
print("Resultados do KNN para reconhecimento de dígitos manuscritos:")
print(classification_report(y_test_digits, y_pred_digits))
print(f"Acurácia: {accuracy_score(y_test_digits, y_pred_digits):.2f}")

# ---------- Análise de Sentimento (Base Textual com TF-IDF) ----------
# Carregar a base de análise de sentimento (Newsgroups com TF-IDF)
categories = ['rec.autos', 'rec.sport.baseball']
newsgroups_train_sentiment = fetch_20newsgroups(subset='train', categories=categories)
newsgroups_test_sentiment = fetch_20newsgroups(subset='test', categories=categories)

# Aplicar TF-IDF
vectorizer = TfidfVectorizer()
X_train_sentiment = vectorizer.fit_transform(newsgroups_train_sentiment.data)
X_test_sentiment = vectorizer.transform(newsgroups_test_sentiment.data)
y_train_sentiment = newsgroups_train_sentiment.target
y_test_sentiment = newsgroups_test_sentiment.target

# Criar e treinar o modelo KNN
knn_sentiment = KNeighborsClassifier(n_neighbors=5)
knn_sentiment.fit(X_train_sentiment, y_train_sentiment)

# Fazer predições e avaliar o modelo
y_pred_sentiment = knn_sentiment.predict(X_test_sentiment)
print("\nResultados do KNN para análise de sentimento (textual):")
print(classification_report(y_test_sentiment, y_pred_sentiment))
print(f"Acurácia: {accuracy_score(y_test_sentiment, y_pred_sentiment):.2f}")
