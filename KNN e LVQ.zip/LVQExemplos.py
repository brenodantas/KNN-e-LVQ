import numpy as np
from minisom import MiniSom
from sklearn.preprocessing import MinMaxScaler
from sklearn.datasets import load_diabetes, fetch_20newsgroups
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.feature_extraction.text import TfidfVectorizer

# ---------- Previsão de Diabetes (Base Numérica) ----------
# Carregar a base de dados de diabetes
diabetes = load_diabetes()
X_diabetes, y_diabetes = diabetes.data, (diabetes.target > 140).astype(int)  # Classificar os pacientes em duas classes

# Dividir a base em treino e teste
X_train_diabetes, X_test_diabetes, y_train_diabetes, y_test_diabetes = train_test_split(X_diabetes, y_diabetes, test_size=0.3, random_state=42)

# Normalizar os dados
scaler = MinMaxScaler()
X_train_diabetes_scaled = scaler.fit_transform(X_train_diabetes)
X_test_diabetes_scaled = scaler.transform(X_test_diabetes)

# Configurar e treinar o MiniSom
som_diabetes = MiniSom(10, 10, X_train_diabetes_scaled.shape[1], learning_rate=0.5, sigma=1.0, random_seed=42)
som_diabetes.train_random(X_train_diabetes_scaled, 1000)

# Função de predição LVQ
def som_predict(som, data, X_train_scaled, y_train):
    winners = np.array([som.winner(x) for x in data])
    labels_map = {}

    for i, (x, label) in enumerate(zip(X_train_scaled, y_train)):
        winner = tuple(som.winner(x))
        if winner not in labels_map:
            labels_map[winner] = []
        labels_map[winner].append(label)

    for winner in labels_map:
        labels_map[winner] = np.bincount(labels_map[winner]).argmax()

    return np.array([labels_map.get(tuple(winner), -1) for winner in winners])

# Predições e avaliação para a base diabetes
y_pred_diabetes = som_predict(som_diabetes, X_test_diabetes_scaled, X_train_diabetes_scaled, y_train_diabetes)
print("\nResultados do LVQ para previsão de diabetes:")
print(f"Acurácia: {accuracy_score(y_test_diabetes, y_pred_diabetes):.2f}")

# ---------- Classificação de Resenhas de Filmes (Base Textual com TF-IDF) ----------
# Categorias válidas do dataset "20 Newsgroups"
categories = ['rec.sport.hockey', 'rec.sport.baseball']  # Substitua por categorias válidas
newsgroups_train_reviews = fetch_20newsgroups(subset='train', categories=categories)
newsgroups_test_reviews = fetch_20newsgroups(subset='test', categories=categories)

# Aplicar TF-IDF
vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
X_train_reviews = vectorizer.fit_transform(newsgroups_train_reviews.data).toarray()
X_test_reviews = vectorizer.transform(newsgroups_test_reviews.data).toarray()
y_train_reviews = newsgroups_train_reviews.target
y_test_reviews = newsgroups_test_reviews.target

# Configurar e treinar o MiniSom
som_reviews = MiniSom(10, 10, X_train_reviews.shape[1], learning_rate=0.5, sigma=1.0, random_seed=42)
som_reviews.train_random(X_train_reviews, 1000)

# Predições e avaliação para a base de resenhas de filmes
y_pred_reviews = som_predict(som_reviews, X_test_reviews, X_train_reviews, y_train_reviews)
print("\nResultados do LVQ para classificação de resenhas de filmes:")
print(f"Acurácia: {accuracy_score(y_test_reviews, y_pred_reviews):.2f}")
